<?php
	/*
		Copyright (c) 2021 FenclWebDesign.com
		This script may not be copied, reproduced or altered in whole or in part.
		We check the Internet regularly for illegal copies of our scripts.
		Do not edit or copy this script for someone else, because you will be held responsible as well.
		This copyright shall be enforced to the full extent permitted by law.
		Licenses to use this script on a single website may be purchased from FenclWebDesign.com
		@Author: Daerik
		*/
	
	use Items\Abstracts;
	use Items\Collections;
	use Items\Enums\Statuses;
	use Items\Members;
	use Items\Members\Actions;
	use JetBrains\PhpStorm\Pure;
	use Members\Messages\Contact;
	use Members\QRCode;
	
	class Membership extends Abstracts\Member {
		private Collections\Comments      $comments;
		private Collections\Contests      $contests;
		private Collections\Likes         $likes;
		private Collections\Notifications $notifications;
		private Collections\Reports       $reports;
		private Collections\Reservations  $reservations;
		private Collections\Settings      $settings;
		private Collections\Tickets       $tickets;
		
		private ?Members\Subscription $subscription;
		private ?Members\Wallet       $wallet;
		
		const LOGGED_IN  = TRUE;
		const LOGGED_OUT = FALSE;
		
		private array $room_ids;
		
		/**
		 * @throws Exception
		 */
		public function __construct() {
			if(isset($this->id)) return;
			
			$membership = self::Init($_SESSION['member']['id'] ?? NULL)?->toArray();
			is_array($membership) && array_map(fn(string $property, mixed $value) => $this->$property = $value, array_keys($membership), $membership);
		}
		
		/**
		 * @param null|int $id
		 *
		 * @return null|$this
		 */
		public static function Init(?int $id = NULL): ?self {
			return Database::Action("SELECT * FROM `members` WHERE `id` = :id", array(
				'id' => $id ?? $_SESSION['member']['id'] ?? NULL
			))->fetchObject(self::class) ?: NULL;
		}
		
		/**
		 * @param PDOStatement $statement
		 *
		 * @return null|static
		 */
		public static function Fetch(PDOStatement $statement): ?self {
			return $statement->fetchObject(self::class) ?: NULL;
		}
		
		/**
		 * @param PDOStatement $statement
		 *
		 * @return self[]
		 */
		public static function FetchAll(PDOStatement $statement): array {
			return $statement->fetchAll(PDO::FETCH_CLASS, self::class);
		}
		
		/**
		 * @param null|string $email
		 * @param bool        $throwable
		 *
		 * @return null|$this
		 *
		 * @throws Exception
		 */
		public static function FromEmail(?string $email, bool $throwable = TRUE): ?self {
			$instance = Database::Action("SELECT * FROM `members` WHERE :email IN (`email`, `username`)", array(
				'email' => $email
			))->fetchObject(self::class) ?: NULL;
			
			if($throwable && is_null($instance)) throw new Exception('Member not found.');
			
			return $instance;
		}
		
		/**
		 * @param null|string $hash
		 * @param bool        $throwable
		 *
		 * @return null|$this
		 *
		 * @throws Exception
		 */
		public static function FromHash(?string $hash, bool $throwable = TRUE): ?self {
			$instance = Database::Action("SELECT * FROM `members` WHERE MD5(`email`) = :hash", array(
				'hash' => $hash
			))->fetchObject(self::class) ?: NULL;
			
			if($throwable && is_null($instance)) throw new Exception('Member not found.');
			
			return $instance;
		}
		
		/**
		 * @return Actions\Account
		 */
		public function account(): Actions\Account {
			return Actions\Account::Init($this);
		}
		
		/**
		 * @param Abstracts\Member $member
		 *
		 * @return Actions\Block
		 */
		public function block(Abstracts\Member $member): Actions\Block {
			return Actions\Block::Init($this, $member);
		}
		
		/**
		 * @return Collections\Comments
		 */
		public function comments(): Collections\Comments {
			return $this->comments ??= new Collections\Comments(Database::Action("SELECT * FROM `member_post_comments` WHERE `member_id` = :member_id", array(
				'member_id' => $this->getId()
			)));
		}
		
		/**
		 * @return Collections\Contests
		 */
		public function contests(): Collections\Contests {
			return $this->contests ??= new Collections\Contests(Database::Action("SELECT * FROM `member_contests` WHERE `member_id` = :member_id", array(
				'member_id' => $this->getId()
			)));
		}
		
		/**
		 * @param Abstracts\Post $post
		 *
		 * @return Actions\Comment
		 */
		public function comment(Abstracts\Post $post): Actions\Comment {
			return Actions\Comment::Init($this, $post);
		}
		
		/**
		 * @param Abstracts\Member $member
		 *
		 * @return Actions\Friend
		 */
		public function friend(Abstracts\Member $member): Actions\Friend {
			return Actions\Friend::Init($this, $member);
		}
		
		/**
		 * @return Collections\Likes
		 */
		public function likes(): Collections\Likes {
			return $this->likes ??= new Collections\Likes(Database::Action("SELECT * FROM `member_post_likes` WHERE `member_id` = :member_id", array(
				'member_id' => $this->getId()
			)));
		}
		
		/**
		 * @param Abstracts\Post $post
		 *
		 * @return Actions\Like
		 */
		public function like(Abstracts\Post $post): Actions\Like {
			return Actions\Like::Init($this, $post);
		}
		
		/**
		 * @return Actions\Log
		 */
		public function log(): Actions\Log {
			return Actions\Log::Init($this);
		}
		
		/**
		 * @param Abstracts\Member $member
		 *
		 * @return Actions\Message
		 */
		public function message(Abstracts\Member $member): Actions\Message {
			return Actions\Message::Init($this, $member);
		}
		
		/**
		 * @param null|bool $unseen
		 *
		 * @return Collections\Notifications
		 */
		public function notifications(?bool $unseen = NULL): Collections\Notifications {
			return $this->notifications ??= new Collections\Notifications(Database::Action("SELECT * FROM `member_notifications` WHERE :member_id IN (`member_1`, `member_2`) AND `initiated_by` != :member_id AND (`seen` != :unseen OR ISNULL(:unseen)) ORDER BY `timestamp` DESC", array(
				'member_id' => $this->getId(),
				'unseen'    => $unseen
			)), $this);
		}
		
		/**
		 * @param Abstracts\Member $member
		 *
		 * @return Actions\Notification
		 */
		public function notify(Abstracts\Member $member): Actions\Notification {
			return Actions\Notification::Init($this, $member);
		}
		
		/**
		 * @return QRCode
		 */
		public function qrCode(): QRCode {
			return new QRCode($this);
		}
		
		/**
		 * @param null|Abstracts\Post   $post
		 * @param null|Abstracts\Member $contact
		 *
		 * @return int
		 */
		public function poll(?Abstracts\Post $post = NULL, ?Abstracts\Member $contact = NULL): int {
			return Database::Action("SELECT UNIX_TIMESTAMP(IFNULL(MAX(`timestamp`), CURDATE())) AS `timestamp` FROM (SELECT GREATEST(MAX(`timestamp`), MAX(`last_timestamp`)) AS `timestamp` FROM `members` WHERE `id` = :member_id UNION SELECT GREATEST(MAX(`timestamp`), MAX(`last_timestamp`)) AS `timestamp` FROM `member_avatars` WHERE `member_id` = :member_id UNION SELECT GREATEST(MAX(`timestamp`), MAX(`last_timestamp`)) AS `timestamp` FROM `member_messages` WHERE :member_id IN (`member_1`, `member_2`) AND `initiated_by` != :member_id UNION SELECT GREATEST(MAX(`timestamp`), MAX(`last_timestamp`)) AS `timestamp` FROM `member_notifications` WHERE :member_id IN (`member_1`, `member_2`) AND `initiated_by` != :member_id UNION SELECT MAX(`timestamp`) AS `timestamp` FROM `member_tickets` WHERE `member_id` = :member_id UNION SELECT MAX(`timestamp`) AS `timestamp` FROM `member_post_comments` WHERE `member_post_id` = :member_post_id UNION SELECT MAX(`timestamp`) AS `timestamp` FROM `member_post_likes` WHERE `member_post_id` = :member_post_id UNION SELECT GREATEST(MAX(`timestamp`), MAX(`last_timestamp`)) AS `timestamp` FROM `member_messages` WHERE :member_id IN (`member_1`, `member_2`) OR :contact_id IN (`member_1`, `member_2`)) AS `collective`", array(
				'member_id'      => $this->getId(),
				'member_post_id' => $post?->getId(),
				'contact_id'     => $contact?->getId()
			))->fetchColumn();
		}
		
		/**
		 * @return Collections\Reports
		 */
		public function reports(): Collections\Reports {
			return $this->reports ??= new Collections\Reports(Database::Action("SELECT * FROM `member_post_reports` WHERE `member_id` = :member_id", array(
				'member_id' => $this->getId()
			)));
		}
		
		/**
		 * @param Abstracts\Post $post
		 *
		 * @return Actions\Report
		 */
		public function report(Abstracts\Post $post): Actions\Report {
			return Actions\Report::Init($this, $post);
		}
		
		/**
		 * @return Collections\Reservations
		 */
		public function reservations(): Collections\Reservations {
			return $this->reservations ??= new Collections\Reservations(Database::Action("SELECT * FROM `member_reservations` WHERE `member_id` = :member_id", array(
				'member_id' => $this->getId()
			)));
		}
		
		/**
		 * @return Collections\Tickets
		 */
		public function tickets(): Collections\Tickets {
			return $this->tickets ??= new Collections\Tickets(Database::Action("SELECT `member_tickets`.* FROM (SELECT `id`, MAX(`timestamp`) AS `timestamp` FROM `member_tickets` WHERE `member_id` = :member_id GROUP BY COALESCE(`member_ticket_id`, `id`)) AS `tickets` JOIN `member_tickets` ON (`tickets`.`id` IN (`member_tickets`.`id`, `member_tickets`.`member_ticket_id`) AND `member_tickets`.`timestamp` = `tickets`.`timestamp`)", array(
				'member_id' => $this->getId()
			)));
		}
		
		/**
		 * @return Contact[]
		 */
		public function getContacts(): array {
			return array_values(array_filter(Database::Action("SELECT `members`.*, MAX(`member_messages`.`timestamp`) AS `recent_timestamp` FROM `members` JOIN `member_messages` ON `members`.`id` = IF(`member_messages`.`member_1` != :member_id, `member_messages`.`member_1`, `member_messages`.`member_2`) WHERE :member_id IN (`member_messages`.`member_1`, `member_messages`.`member_2`) GROUP BY `members`.`id` ORDER BY `recent_timestamp` DESC", array(
				'member_id' => $this->getId()
			))->fetchAll(PDO::FETCH_CLASS, Contact::class), fn(Contact $contact) => $this->getBlockStatus($contact)->is(Statuses\Block::NONE)));
		}
		
		/**
		 * @param null|int $room_id
		 *
		 * @return null|Members\Room
		 */
		public function getRoom(?int $room_id): ?Members\Room {
			return Members\Room::Fetch(Database::Action("SELECT * FROM `member_rooms` WHERE `member_id` = :member_id AND `room_id` = :room_id", array(
				'member_id' => $this->getId(),
				'room_id'   => $room_id
			)));
		}
		
		/**
		 * @return int[]
		 */
		public function getRoomIds(): array {
			return $this->room_ids['all'] ??= Database::Action("SELECT `room_id` FROM `member_rooms` WHERE `member_id` = :member_id", array(
				'member_id' => $this->getId()
			))->fetchAll(PDO::FETCH_COLUMN);
		}
		
		/**
		 * @return int[]
		 */
		public function getRoomFavoriteIds(): array {
			return $this->room_ids['favorite'] ??= Database::Action("SELECT `room_id` FROM `member_rooms` WHERE `favorite` IS TRUE AND `member_id` = :member_id", array(
				'member_id' => $this->getId()
			))->fetchAll(PDO::FETCH_COLUMN);
		}
		
		/**
		 * @return int[]
		 */
		public function getRoomNotificationIds(): array {
			return $this->room_ids['notification'] ??= Database::Action("SELECT `room_id` FROM `member_rooms` WHERE `notification` IS TRUE AND `member_id` = :member_id", array(
				'member_id' => $this->getId()
			))->fetchAll(PDO::FETCH_COLUMN);
		}
		
		/**
		 * @return int[]
		 */
		public function getRoomReviewIds(): array {
			return $this->room_ids['review'] ??= Database::Action("SELECT `room_id` FROM `member_rooms` WHERE `review_id` IS NOT NULL AND `member_id` = :member_id", array(
				'member_id' => $this->getId()
			))->fetchAll(PDO::FETCH_COLUMN);
		}
		
		/**
		 * @return Collections\Settings
		 */
		public function settings(): Collections\Settings {
			return $this->settings ??= new Collections\Settings(Database::Action("SELECT * FROM `member_settings`"));
		}
		
		/**
		 * @return null|Members\Subscription
		 */
		public function subscription(): ?Members\Subscription {
			return $this->subscription ??= Members\Subscription::Fetch(Database::Action("SELECT * FROM `member_subscriptions` WHERE`member_id` = :member_id AND `status` = :status", array(
				'member_id' => $this->getId(),
				'status'    => Statuses\Subscription::ACTIVE->getValue()
			)));
		}
		
		/**
		 * @param null|Items\Subscription $subscription
		 *
		 * @return bool
		 */
		public function hasSubscription(?Items\Subscription $subscription): bool {
			return (bool)Database::Action("SELECT * FROM `member_subscriptions` WHERE`member_id` = :member_id AND `subscription_id` = :subscription_id", array(
				'member_id'       => $this->getId(),
				'subscription_id' => $subscription?->getId()
			))->rowCount();
		}
		
		/**
		 * @return null|Members\Wallet
		 */
		public function wallet(): ?Members\Wallet {
			return $this->wallet ??= Members\Wallet::Fetch(Database::Action("SELECT * FROM `member_wallets` WHERE `default` IS TRUE AND `member_id` = :member_id", array(
				'member_id' => $this->getId()
			)));
		}
		
		/**
		 * @return Collections\Settings
		 */
		public static function FetchSettings(): Collections\Settings {
			return new Collections\Settings(Database::Action("SELECT * FROM `member_settings`"));
		}
		
		/**
		 * Redirects user whether logged in or not.
		 *
		 * @param bool   $status TRUE (Logged In) || FALSE (Logged Out)
		 * @param string $url
		 * @param bool   $rel_link
		 *
		 * @return void
		 */
		public static function CheckRedirect(bool $status, string $url, bool $rel_link = FALSE): void {
			if(static::LoggedIn() !== $status) {
				Helpers::Redirect($url, $rel_link);
			}
			
			static::LoggedIn() && static::CheckBan();
		}
		
		/**
		 * Checks if member is logged in.
		 *
		 * @param bool $status TRUE (Logged In) || FALSE (Logged Out)
		 *
		 * @return bool
		 */
		public static function LoggedIn(bool $status = TRUE): bool {
			return !empty($_SESSION['member']) === $status;
		}
		
		/**
		 * Checks if member is banned.
		 *
		 * @return void
		 */
		public static function CheckBan(): void {
			$member = new Membership();
			
			if($member->isBanned()) {
				unset($_SESSION['member']);
				header('Location: /members/login');
				exit;
			}
		}
		
		/**
		 * @param string      $email
		 * @param null|string $ignore
		 *
		 * @return bool
		 */
		public static function EmailExists(string $email, ?string $ignore = NULL): bool {
			return Database::Action("SELECT `id` FROM `members` WHERE `email` = :email AND :email != :ignore", array(
				'email'  => $email,
				'ignore' => $ignore
			))->rowCount();
		}
		
		/**
		 * @param string      $username
		 * @param null|string $ignore
		 *
		 * @return bool
		 */
		public static function UsernameExists(string $username, ?string $ignore = NULL): bool {
			return Database::Action("SELECT `id` FROM `members` WHERE `username` = :username AND :username != :ignore", array(
				'username' => $username,
				'ignore'   => $ignore
			))->rowCount();
		}
		
		/**
		 * Only available for paid members, so if free always display.
		 *
		 * @return bool
		 */
		public function isDisplayRsvps(): bool {
			return $this->subscription()?->isFree() ?: $this->display_rsvps;
		}
		
		/**
		 * @return int
		 */
		public function getDailyMessageCount(): int {
			return Database::Action("SELECT COUNT(`id`) AS `count` FROM `member_messages` WHERE `initiated_by` = :member_id AND `timestamp` >= DATE_SUB(NOW(), INTERVAL 1 DAY)", array(
				'member_id' => $this->getId()
			))->fetchColumn();
		}
		
		/**
		 * @return string
		 */
		#[Pure] public function getHash(): string {
			return md5($this->getEmail());
		}
		
		/**
		 * @return string
		 */
		#[Pure] public function getVerificationLink(): string {
			return Helpers::CurrentWebsite(sprintf("/members/verify-email/%s", $this->getHash()));
		}
		
		/**
		 * @return string
		 */
		#[Pure] public function getPasswordResetLink(): string {
			return Helpers::CurrentWebsite(sprintf("/members/reset-password/%s", $this->getHash()));
		}
	}
