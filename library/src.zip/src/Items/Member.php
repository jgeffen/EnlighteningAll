<?php
	/*
	Copyright (c) 2021 FenclWebDesign.com
	This script may not be copied, reproduced or altered in whole or in part.
	We check the Internet regularly for illegal copies of our scripts.
	Do not edit or copy this script for someone else, because you will be held responsible as well.
	This copyright shall be enforced to the full extent permitted by law.
	Licenses to use this script on a single website may be purchased from FenclWebDesign.com
	@Author: Deryk
	*/
	
	namespace Items;
	
	use Database;
	use Exception;
	use Items;
	use Items\Enums\Statuses;
	use PDO;
	use PDOStatement;
	
	class Member extends Abstracts\Member {
		private ?Members\Subscription $subscription;
		
		/**
		 * @param null|int $id
		 *
		 * @return null|$this
		 */
		public static function Init(?int $id): ?self {
			return Database::Action("SELECT * FROM `members` WHERE `id` = :id", array(
				'id' => $id
			))->fetchObject(self::class) ?: NULL;
		}
		
		/**
		 * @param PDOStatement $statement
		 *
		 * @return null|static
		 */
		public static function Fetch(PDOStatement $statement): ?self {
			return $statement->fetchObject(self::class) ?: NULL;
		}
		
		/**
		 * @param PDOStatement $statement
		 *
		 * @return self[]
		 */
		public static function FetchAll(PDOStatement $statement): array {
			return $statement->fetchAll(PDO::FETCH_CLASS, self::class);
		}
		
		/**
		 * @return null|Members\Subscription
		 */
		public function subscription(): ?Members\Subscription {
			return $this->subscription ??= Members\Subscription::Fetch(Database::Action("SELECT * FROM `member_subscriptions` WHERE`member_id` = :member_id AND `status` = :status", array(
				'member_id' => $this->getId(),
				'status'    => Statuses\Subscription::ACTIVE->getValue()
			)));
		}
		
		/**
		 * @param null|Subscription $subscription
		 *
		 * @return bool
		 */
		public function hasSubscription(?Items\Subscription $subscription): bool {
			return (bool)Database::Action("SELECT * FROM `member_subscriptions` WHERE`member_id` = :member_id AND `subscription_id` = :subscription_id", array(
				'member_id'       => $this->getId(),
				'subscription_id' => $subscription?->getId()
			))->rowCount();
		}
		
		/**
		 * @param null|int $author
		 *
		 * @return void
		 *
		 * @throws Exception
		 */
		public function issueFreeDrink(?int $author = NULL): void {
			if($this->subscription()?->isPaid()) {
				Database::Action("INSERT INTO `member_free_drinks` SET `member_id` = :member_id, `expiration_date` = :expiration_date, `author` = :author, `user_agent` = :user_agent, `ip_address` = :ip_address ON DUPLICATE KEY UPDATE `expiration_date` = :expiration_date, `author` = :author, `user_agent` = :user_agent, `ip_address` = :ip_address", array(
					'member_id'       => $this->getId(),
					'expiration_date' => $this->subscription()->getRenewalDate()->format('Y-m-d H:i:s'),
					'author'          => $author,
					'user_agent'      => filter_input(INPUT_SERVER, 'HTTP_USER_AGENT'),
					'ip_address'      => filter_input(INPUT_SERVER, 'REMOTE_ADDR', FILTER_VALIDATE_IP)
				));
			} else {
				throw new Exception('Member has no paid subscription.');
			}
		}
	}