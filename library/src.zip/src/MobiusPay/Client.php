<?php
	/*
	Copyright (c) 2020, 2021, 2022 FenclWebDesign.com
	This script may not be copied, reproduced or altered in whole or in part.
	We check the Internet regularly for illegal copies of our scripts.
	Do not edit or copy this script for someone else, because you will be held responsible as well.
	This copyright shall be enforced to the full extent permitted by law.
	Licenses to use this script on a single website may be purchased from FenclWebDesign.com
	@Author: Deryk
	*/
	
	namespace MobiusPay;
	
	use Config\MobiusPay as Config;
	use DateTime;
	use Exception;
	use Freelancehunt\Validators\CreditCard;
	use Helpers;
	use JetBrains\PhpStorm\Pure;
	
	/**
	 * MobiusPay Client
	 *
	 * @Link: https://secure.mobiusgateway.com/merchants/resources/integration/integration_portal.php
	 */
	class Client {
		public const string MERCHANT_NAME      = 'MobiusPay';
		public const string MERCHANT_USERAGENT = 'MobiusPayClient-PHP';
		public const string MERCHANT_ENDPOINT  = 'https://secure.mobiusgateway.com/api/transact.php';
		
		public const int RESPONSE_APPROVED = 1;
		public const int RESPONSE_DECLINED = 2;
		public const int RESPONSE_ERROR    = 3;
		
		public const string TYPE_AUTH     = 'auth';
		public const string TYPE_CAPTURE  = 'capture';
		public const string TYPE_CREDIT   = 'credit';
		public const string TYPE_REFUND   = 'refund';
		public const string TYPE_SALE     = 'sale';
		public const string TYPE_UPDATE   = 'update';
		public const string TYPE_VALIDATE = 'validate';
		public const string TYPE_VOID     = 'void';
		
		private array $billing     = array();
		private array $creditCard  = array();
		private array $order       = array();
		private array $shipping    = array();
		private array $transaction = array();
		private bool  $verbose     = FALSE;
		
		private Config  $config;
		private float   $amount;
		private string  $account_number;
		private ?string $transaction_id;
		private string  $type;
		
		/**
		 * @param string|null $mode "development" | "production"
		 * @param string|null $config_path
		 *
		 * @throws Exception
		 */
		public function __construct(?string $mode = NULL, ?string $config_path = NULL) {
			$this->config = new Config($mode, $config_path);
		}
		
		/**
		 * Gets form options for MobiusPay.
		 *
		 * @param string|null $type
		 * @param string|null $sub_type
		 * @param string|null $key
		 *
		 * @return array|string|null
		 */
		public static function FormOptions(?string $type = NULL, ?string $sub_type = NULL, ?string $key = NULL): array|string|null {
			$array = match ($type) {
				'countries'         => array(
					'US' => 'United States of America'
				),
				'credit_card_types' => array(
					'Visa'       => 'Visa',
					'MasterCard' => 'Master Card',
					'Discover'   => 'Discover',
					'Amex'       => 'American Express',
				),
				'expiration_months' => array_reduce(range(1, 12), function($items, $item) {
					$items[str_pad($item, 2, '0', STR_PAD_LEFT)] = str_pad($item, 2, '0', STR_PAD_LEFT) . ' - ' . date('F', mktime(0, 0, 0, $item, 10));
					
					return $items;
				}),
				'expiration_years'  => array_reduce(range(date('Y'), date('Y', strtotime('+15 Years'))), function($items, $item) {
					$items[DateTime::createFromFormat('Y', $item)->format('y')] = $item;
					
					return $items;
				}),
				'states'            => match ($sub_type) {
					'US'    => array(
						'AL' => 'Alabama',
						'AK' => 'Alaska',
						'AZ' => 'Arizona',
						'AR' => 'Arkansas',
						'CA' => 'California',
						'CO' => 'Colorado',
						'CT' => 'Connecticut',
						'DE' => 'Delaware',
						'DC' => 'District of Columbia',
						'FL' => 'Florida',
						'GA' => 'Georgia',
						'HI' => 'Hawaii',
						'ID' => 'Idaho',
						'IL' => 'Illinois',
						'IN' => 'Indiana',
						'IA' => 'Iowa',
						'KS' => 'Kansas',
						'KY' => 'Kentucky',
						'LA' => 'Louisiana',
						'ME' => 'Maine',
						'MD' => 'Maryland',
						'MA' => 'Massachusetts',
						'MI' => 'Michigan',
						'MN' => 'Minnesota',
						'MS' => 'Mississippi',
						'MO' => 'Missouri',
						'MT' => 'Montana',
						'NE' => 'Nebraska',
						'NV' => 'Nevada',
						'NH' => 'New Hampshire',
						'NJ' => 'New Jersey',
						'NM' => 'New Mexico',
						'NY' => 'New York',
						'NC' => 'North Carolina',
						'ND' => 'North Dakota',
						'OH' => 'Ohio',
						'OK' => 'Oklahoma',
						'OR' => 'Oregon',
						'PA' => 'Pennsylvania',
						'RI' => 'Rhode Island',
						'SC' => 'South Carolina',
						'SD' => 'South Dakota',
						'TN' => 'Tennessee',
						'TX' => 'Texas',
						'UT' => 'Utah',
						'VT' => 'Vermont',
						'VA' => 'Virginia',
						'WA' => 'Washington',
						'WV' => 'West Virginia',
						'WI' => 'Wisconsin',
						'WY' => 'Wyoming'
					),
					default => array()
				},
				default             => array(),
			};
			
			return is_null($key) ? $array : $array[$key] ?? NULL;
		}
		
		/**
		 * Generates an invoice number based on the parameters sent.
		 *
		 * @param string $prefix
		 * @param mixed  ...$details
		 *
		 * @return string
		 */
		public static function GenerateInvoice(string $prefix = 'MP', ...$details): string {
			return sprintf("%s-%s", $prefix, substr(strtoupper(md5(implode($details) . time())), 0, 7));
		}
		
		/**
		 * @param string      $mode "development" | "production"
		 * @param string|null $config_path
		 *
		 * @throws Exception
		 */
		public function setMode(string $mode, ?string $config_path = NULL): void {
			$this->config = new Config($mode, $config_path);
		}
		
		/**
		 * Set credit card to be used for transactions
		 *
		 * @param string $account    String representing the credit card account
		 * @param string $type       String representing the credit card type
		 * @param string $expiration String representing the credit card expiration
		 * @param string $cvv        String representing the credit card cvv
		 *
		 * @return Client
		 *
		 * @throws Exception
		 */
		public function setCreditCard(string $account, string $type, string $expiration, string $cvv): Client {
			$account = preg_replace('/[^\d]/', '', $account);
			
			if(self::ValidateAccount($account, $type)) throw new Exception('Invalid credit card number');
			if(self::ValidateExpiration($expiration)) throw new Exception('Invalid expiration date');
			if(self::ValidateCVV($cvv, $type)) throw new Exception('Invalid CVV');
			
			$this->account_number = self::MaskCreditCard($account);
			$this->creditCard     = array(
				'account'    => $account,
				'expiration' => $expiration,
				'cvv'        => $cvv,
				'type'       => $type
			);
			
			return $this;
		}
		
		/**
		 * Validate a card number knowing the type
		 *
		 * @param string $account String representing the credit card number
		 * @param string $type    String representing the credit card type
		 *
		 * @return bool
		 */
		public static function ValidateAccount(string $account, string $type): bool {
			return !CreditCard::validCreditCard($account, strtolower($type))['valid'];
		}
		
		/**
		 * Validate the expiration date
		 *
		 * @param string $cardExp String representing 2-digit month and 2/4 digit year of credit card expiration
		 *
		 * @return bool
		 */
		public static function ValidateExpiration(string $cardExp): bool {
			list($expMonth, $expYear) = strlen($cardExp) == 6
				? array(substr($cardExp, 0, 2), substr($cardExp, -4))
				: array(substr($cardExp, 0, 2), '20' . substr($cardExp, -2));
			
			return !CreditCard::validDate($expYear, $expMonth);
		}
		
		/**
		 * Validate the CVV
		 *
		 * @param string $cardCvv  String representing the credit card cvv
		 * @param string $cardType String representing the credit card type
		 *
		 * @return bool
		 */
		public static function ValidateCVV(string $cardCvv, string $cardType): bool {
			return !CreditCard::validCvc($cardCvv, strtolower($cardType));
		}
		
		/**
		 * Masks credit card number for PCI compliance.
		 *
		 * @param $credit_card
		 *
		 * @return string
		 */
		public static function MaskCreditCard($credit_card): string {
			$credit_card = (string)preg_replace('/[^0-9]/', '', $credit_card);
			$length      = strlen($credit_card);
			
			return substr($credit_card, 0, 1) . str_repeat('X', $length - 5) . substr($credit_card, $length - 4, 4);
		}
		
		/**
		 * Gets the string equivalent of the payment status.
		 *
		 * @return string
		 */
		public function getPaymentStatus(): string {
			return self::PaymentStatus($this->getTransaction('response'));
		}
		
		/**
		 * Gets string equivalent of payment status.
		 *
		 * @param int $response
		 *
		 * @return string
		 */
		public static function PaymentStatus(int $response): string {
			return match ($response) {
				self::RESPONSE_APPROVED => 'Approved',
				self::RESPONSE_DECLINED => 'Declined',
				self::RESPONSE_ERROR    => 'Errored',
				default                 => 'Unknown'
			};
		}
		
		/**
		 * Gets the response from $this->process().
		 *
		 * @param string|null $key
		 *
		 * @return array|string|null array(
		 *      'authcode'               int,        // Transaction authorization code.
		 *      'avsresponse'            string|int, // AVS response code (See Appendix 1).
		 *      'billing_id'             int,        // Customer vault billing ID
		 *      'customer_vault_id'      int,        // Customer vault lookup ID
		 *      'cvvresponse'            string,     // CVV response code (See Appendix 2).
		 *      'emv_auth_response_data' string,     // This will optionally come back when any chip card data is provided on the authorization.
		 *      'orderid'                string|int, // The original order id passed in the transaction request.
		 *      'response'               int,        // 1 = Transaction Approved, 2 = Transaction Declined, 3 = Error in transaction data or system error.
		 *      'response_code'          int,        // Numeric mapping of processor responses (See Appendix 3).
		 *      'responsetext'           string,     // Textual response.
		 *      'shipping_id'            int,        // Customer vault shipping ID
		 *      'transactionid'          string|int, // Payment gateway transaction id.
		 * )
		 *
		 * @link https://secure.mobiusgateway.com/merchants/resources/integration/integration_portal.php#transaction_response_variables
		 */
		public function getTransaction(?string $key = NULL): array|string|null {
			$array = filter_var_array($this->transaction, array(
				'authcode'               => FILTER_VALIDATE_INT,
				'avsresponse'            => FILTER_DEFAULT,
				'billing_id'             => FILTER_VALIDATE_INT,
				'customer_vault_id'      => FILTER_VALIDATE_INT,
				'cvvresponse'            => FILTER_DEFAULT,
				'emv_auth_response_data' => FILTER_DEFAULT,
				'orderid'                => FILTER_DEFAULT,
				'response'               => FILTER_VALIDATE_INT,
				'response_code'          => FILTER_VALIDATE_INT,
				'responsetext'           => FILTER_DEFAULT,
				'shipping_id'            => FILTER_VALIDATE_INT,
				'transactionid'          => FILTER_DEFAULT
			)) ?: array();
			
			return is_null($key) ? $array : $array[$key] ?? NULL;
		}
		
		/**
		 * Transaction details to be stored in the database.
		 *
		 * @param array $form_values
		 *
		 * @return array
		 */
		public function getTransactionDetails(array $form_values = array()): array {
			return array_merge($form_values, array_combine(array_map(function($key) {
				return sprintf("MOBIUSPAY_%s", strtoupper(str_replace('[', '_', trim($key, ']'))));
			}, array_keys($this->transaction)), $this->transaction));
		}
		
		/**
		 * Gets the masked account number.
		 *
		 * @return string|null
		 */
		public function getAccountNumber(): ?string {
			return $this->account_number ?? NULL;
		}
		
		/**
		 * Gets the credit card account type.
		 *
		 * @return string|null
		 */
		public function getAccountType(): ?string {
			return $this->getCreditCard('type');
		}
		
		/**
		 * @param string|null $key
		 *
		 * @return array|string|null
		 */
		private function getCreditCard(?string $key = NULL): array|string|null {
			$array = filter_var_array($this->creditCard, array(
				'account'    => FILTER_DEFAULT,
				'cvv'        => FILTER_DEFAULT,
				'expiration' => FILTER_DEFAULT,
				'type'       => FILTER_DEFAULT
			)) ?: array();
			
			return is_null($key) ? $array : $array[$key] ?? NULL;
		}
		
		/**
		 * @param string $format
		 *
		 * @return string
		 * @throws \DateMalformedStringException
		 */
		public function getExpirationDate(string $format = 'Y-m-d'): string {
			return DateTime::createFromFormat('my', $this->getCreditCard('expiration'))->modify('Last Day of This Month')->format($format);
		}
		
		/**
		 * Do transaction of matching type.
		 *
		 * @param float|null $amount Float representing the amount to be validated.
		 *
		 * @throws Exception
		 */
		public function doTransaction(?float $amount = NULL): void {
			match ($this->getType()) {
				self::TYPE_AUTH     => $this->authTransaction($amount),
				self::TYPE_CAPTURE  => $this->captureTransaction($amount),
				self::TYPE_CREDIT   => $this->creditTransaction($amount),
				self::TYPE_REFUND   => $this->refundTransaction($amount),
				self::TYPE_SALE     => $this->saleTransaction($amount),
				self::TYPE_UPDATE   => $this->updateTransaction(),
				self::TYPE_VALIDATE => $this->validateTransaction($amount),
				self::TYPE_VOID     => $this->voidTransaction(),
				default             => throw new Exception('Unmatched transaction type. Please refer to documentation.'),
			};
		}
		
		/**
		 * @return string
		 */
		public function getType(): string {
			return $this->type;
		}
		
		/**
		 * Sets the transaction type to process.
		 *
		 * @param string $type See TYPE_* constants.
		 *
		 * @return Client
		 *
		 * @link https://secure.mobiusgateway.com/merchants/resources/integration/integration_portal.php#transaction_types
		 */
		public function setType(string $type): Client {
			$this->type = $type;
			
			return $this;
		}
		
		/**
		 * Transaction authorizations are authorized immediately but are not flagged for settlement. These transactions
		 * must be flagged for settlement using the capture transaction type.
		 *
		 * @param float $amount Float representing the amount to be authorized.
		 *
		 * @throws Exception
		 */
		private function authTransaction(float $amount): void {
			$this->setAmount($amount);
			$this->process(array(
				// Transaction Information
				'type'                => $this->getType(),
				'amount'              => $this->getAmount(),
				'ccnumber'            => $this->getCreditCard('account'),
				'ccexp'               => $this->getCreditCard('expiration'),
				'cvv'                 => $this->getCreditCard('cvv'),
				
				// Order Information
				'ipaddress'           => $this->getOrder('ip_address'),
				'orderid'             => $this->getOrder('id'),
				'order_description'   => $this->getOrder('description'),
				'tax'                 => $this->getOrder('tax'),
				'shipping'            => $this->getOrder('shipping'),
				'ponumber'            => $this->getOrder('po_number'),
				
				// Billing Information
				'first_name'          => $this->getBilling('first_name'),
				'last_name'           => $this->getBilling('last_name'),
				'company'             => $this->getBilling('company'),
				'address1'            => $this->getBilling('address_line_1'),
				'address2'            => $this->getBilling('address_line_2'),
				'city'                => $this->getBilling('city'),
				'state'               => $this->getBilling('state'),
				'zip'                 => $this->getBilling('zip_code'),
				'country'             => $this->getBilling('country'),
				'phone'               => $this->getBilling('phone'),
				'fax'                 => $this->getBilling('fax'),
				'email'               => $this->getBilling('email'),
				'website'             => $this->getBilling('website'),
				
				// Shipping Information
				'shipping_first_name' => $this->getShipping('first_name'),
				'shipping_last_name'  => $this->getShipping('last_name'),
				'shipping_company'    => $this->getShipping('company'),
				'shipping_address1'   => $this->getShipping('address_line_1'),
				'shipping_address2'   => $this->getShipping('address_line_2'),
				'shipping_city'       => $this->getShipping('city'),
				'shipping_state'      => $this->getShipping('state'),
				'shipping_zip'        => $this->getShipping('zip_code'),
				'shipping_country'    => $this->getShipping('country'),
				'shipping_email'      => $this->getShipping('email')
			));
		}
		
		/**
		 * @param float|string $amount The numeric currency value.
		 */
		private function setAmount(float|string $amount): void {
			$dot_pos   = strrpos($amount, '.');
			$comma_pos = strrpos($amount, ',');
			$separator = $dot_pos > $comma_pos && $dot_pos ? $dot_pos : ($comma_pos > $dot_pos && $comma_pos ? $comma_pos : FALSE);
			
			$this->amount = !$separator
				? floatval(preg_replace('/[^0-9]/', '', $amount))
				: floatval(sprintf("%d.%d", preg_replace('/[^0-9]/', '', substr($amount, 0, $separator)), preg_replace('/[^0-9]/', '', substr($amount, $separator + 1, strlen($amount)))));
		}
		
		/**
		 * Send NVP string to MobiusPay and return response
		 *
		 * @param array $payload
		 *
		 * @throws Exception
		 *
		 * @link https://secure.mobiusgateway.com/merchants/resources/integration/integration_portal.php#transaction_variables
		 */
		private function process(array $payload): void {
			$payload += array('security_key' => $this->config->getPrivateKey());
			
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_POSTFIELDS     => http_build_query($payload, '', '&'),
				CURLOPT_HTTPHEADER     => array('Content-Type: application/x-www-form-urlencoded'),
				CURLOPT_RETURNTRANSFER => TRUE,
				CURLOPT_SSL_VERIFYPEER => FALSE,
				CURLOPT_SSLVERSION     => 6,
				CURLOPT_TIMEOUT        => 45,
				CURLOPT_URL            => self::MERCHANT_ENDPOINT,
				CURLOPT_USERAGENT      => self::MERCHANT_USERAGENT,
				CURLOPT_VERBOSE        => $this->isVerbose()
			));
			
			$this->transaction = self::ParseResponse(curl_exec($curl));
			if(!$this->transaction) {
				$curl_errno = curl_errno($curl);
				$curl_error = curl_error($curl);
				
				throw new Exception(sprintf("cURL error: [%s] %s", $curl_errno, $curl_error));
			}
		}
		
		/**
		 * @return bool
		 */
		public function isVerbose(): bool {
			return $this->verbose;
		}
		
		/**
		 * @param bool $verbose
		 *
		 * @return Client
		 */
		public function setVerbose(bool $verbose): Client {
			$this->verbose = $verbose;
			return $this;
		}
		
		/**
		 * Converts Name-Value pair to array
		 *
		 * @param string $string String representing a Name-Value pair
		 *
		 * @return array
		 */
		public static function ParseResponse(string $string): array {
			$array = array();
			
			while(strlen($string)) {
				$key_pos         = strpos($string, '=');
				$key_val         = substr($string, 0, $key_pos);
				$val_pos         = strpos($string, '&') ?: strlen($string);
				$val_val         = substr($string, $key_pos + 1, $val_pos - $key_pos - 1);
				$array[$key_val] = urldecode($val_val);
				$string          = substr($string, $val_pos + 1, strlen($string));
			}
			
			return $array;
		}
		
		/**
		 * @param bool $formatted Set true to return a USD formatted string.
		 *
		 * @return float|string
		 */
		#[Pure]
		public function getAmount(bool $formatted = FALSE): float|string {
			return !$formatted ? $this->amount : Helpers::FormatCurrency($this->amount);
		}
		
		/**
		 * @param string|null $key
		 *
		 * @return array|string|null
		 */
		public function getOrder(?string $key = NULL): array|string|null {
			$array = filter_var_array($this->order, array(
				'description' => FILTER_DEFAULT,
				'id'          => FILTER_DEFAULT,
				'ip_address'  => FILTER_DEFAULT,
				'po_number'   => FILTER_DEFAULT,
				'shipping'    => FILTER_DEFAULT,
				'tax'         => FILTER_VALIDATE_FLOAT,
				'comments'    => FILTER_DEFAULT
			)) ?: array();
			
			return is_null($key) ? $array : $array[$key] ?? NULL;
		}
		
		/**
		 * Set order information
		 *
		 * @param array $order Array representing the order information
		 *
		 * @return Client
		 *
		 */
		public function setOrder(array $order): Client {
			$this->order = filter_var_array($order, array(
				'description' => FILTER_DEFAULT,
				'id'          => FILTER_DEFAULT,
				'ip_address'  => FILTER_DEFAULT,
				'po_number'   => FILTER_DEFAULT,
				'shipping'    => FILTER_DEFAULT,
				'tax'         => FILTER_VALIDATE_FLOAT,
				'comments'    => FILTER_DEFAULT
			)) ?: array();
			
			return $this;
		}
		
		/**
		 * @param string|null $key
		 *
		 * @return array|string|null
		 */
		public function getBilling(?string $key = NULL): array|string|null {
			$array = filter_var_array($this->billing, array(
				'address_line_1' => FILTER_DEFAULT,
				'address_line_2' => FILTER_DEFAULT,
				'city'           => FILTER_DEFAULT,
				'company'        => FILTER_DEFAULT,
				'country'        => FILTER_DEFAULT,
				'email'          => FILTER_VALIDATE_EMAIL,
				'fax'            => FILTER_DEFAULT,
				'first_name'     => FILTER_DEFAULT,
				'last_name'      => FILTER_DEFAULT,
				'phone'          => FILTER_DEFAULT,
				'state'          => FILTER_DEFAULT,
				'website'        => FILTER_VALIDATE_URL,
				'zip_code'       => FILTER_DEFAULT
			)) ?: array();
			
			return is_null($key) ? $array : $array[$key] ?? NULL;
		}
		
		/**
		 * Set billing information.
		 *
		 * @param array $billing Array representing the customer's billing information
		 *
		 * @return Client
		 *
		 */
		public function setBilling(array $billing): Client {
			$this->billing = filter_var_array($billing, array(
				'address_line_1' => FILTER_DEFAULT,
				'address_line_2' => FILTER_DEFAULT,
				'city'           => FILTER_DEFAULT,
				'company'        => FILTER_DEFAULT,
				'country'        => FILTER_DEFAULT,
				'email'          => FILTER_VALIDATE_EMAIL,
				'fax'            => FILTER_DEFAULT,
				'first_name'     => FILTER_DEFAULT,
				'last_name'      => FILTER_DEFAULT,
				'phone'          => FILTER_DEFAULT,
				'state'          => FILTER_DEFAULT,
				'website'        => FILTER_VALIDATE_URL,
				'zip_code'       => FILTER_DEFAULT
			)) ?: array();
			
			return $this;
		}
		
		/**
		 * @param string|null $key
		 *
		 * @return array|string|null
		 */
		public function getShipping(?string $key = NULL): array|string|null {
			$array = filter_var_array($this->shipping, array(
				'address_line_1' => FILTER_DEFAULT,
				'address_line_2' => FILTER_DEFAULT,
				'city'           => FILTER_DEFAULT,
				'company'        => FILTER_DEFAULT,
				'country'        => FILTER_DEFAULT,
				'email'          => FILTER_VALIDATE_EMAIL,
				'first_name'     => FILTER_DEFAULT,
				'last_name'      => FILTER_DEFAULT,
				'state'          => FILTER_DEFAULT,
				'zip_code'       => FILTER_DEFAULT
			)) ?: array();
			
			return is_null($key) ? $array : $array[$key] ?? NULL;
		}
		
		/**
		 * Set shipping information.
		 *
		 * @param array $shipping Array representing the customer's shipping information
		 *
		 * @return Client
		 *
		 */
		public function setShipping(array $shipping): Client {
			$this->shipping = filter_var_array($shipping, array(
				'address_line_1' => FILTER_DEFAULT,
				'address_line_2' => FILTER_DEFAULT,
				'city'           => FILTER_DEFAULT,
				'company'        => FILTER_DEFAULT,
				'country'        => FILTER_DEFAULT,
				'email'          => FILTER_VALIDATE_EMAIL,
				'first_name'     => FILTER_DEFAULT,
				'last_name'      => FILTER_DEFAULT,
				'state'          => FILTER_DEFAULT,
				'zip_code'       => FILTER_DEFAULT
			)) ?: array();
			
			return $this;
		}
		
		/**
		 * Transaction captures flag existing authorizations for settlement. Only authorizations can be captured. Captures
		 * can be submitted for an amount equal to or less than the original authorization.
		 *
		 * @param float $amount Float representing the amount to be captured.
		 *
		 * @throws Exception
		 */
		private function captureTransaction(float $amount): void {
			$this->setAmount($amount);
			$this->process(array(
				// Transaction Information
				'type'          => $this->getType(),
				'transactionid' => $this->getTransactionId(),
				'amount'        => $this->getAmount()
			));
		}
		
		/**
		 * @return string|null
		 */
		private function getTransactionId(): ?string {
			return $this->transaction_id;
		}
		
		/**
		 * Transaction credits apply an amount to the cardholder's card that was not originally processed through the
		 * Gateway. In most situations credits are disabled as transaction refunds should be used instead.
		 *
		 * @param float $amount Float representing the amount to be credited.
		 *
		 * @throws Exception
		 */
		private function creditTransaction(float $amount): void {
			$this->setAmount($amount);
			$this->process(array(
				// Transaction Information
				'type'              => $this->getType(),
				'amount'            => $this->getAmount(),
				'ccnumber'          => $this->getCreditCard('account'),
				'ccexp'             => $this->getCreditCard('expiration'),
				'cvv'               => $this->getCreditCard('cvv'),
				
				// Order Information
				'ipaddress'         => $this->getOrder('ip_address'),
				'orderid'           => $this->getOrder('id'),
				'order_description' => $this->getOrder('description'),
				'tax'               => $this->getOrder('tax'),
				'shipping'          => $this->getOrder('shipping'),
				'ponumber'          => $this->getOrder('po_number'),
				
				// Billing Information
				'first_name'        => $this->getBilling('first_name'),
				'last_name'         => $this->getBilling('last_name'),
				'company'           => $this->getBilling('company'),
				'address1'          => $this->getBilling('address_line_1'),
				'address2'          => $this->getBilling('address_line_2'),
				'city'              => $this->getBilling('city'),
				'state'             => $this->getBilling('state'),
				'zip'               => $this->getBilling('zip_code'),
				'country'           => $this->getBilling('country'),
				'phone'             => $this->getBilling('phone'),
				'fax'               => $this->getBilling('fax'),
				'email'             => $this->getBilling('email'),
				'website'           => $this->getBilling('website')
			));
		}
		
		/**
		 * Transaction refunds will reverse a previously settled or pending settlement transaction. If the transaction has not
		 * been settled, a transaction void can also reverse it.
		 *
		 * @param float $amount Float representing the amount to be refunded.
		 *
		 * @throws Exception
		 */
		private function refundTransaction(float $amount): void {
			$this->setAmount($amount);
			$this->process(array(
				// Transaction Information
				'type'          => $this->getType(),
				'transactionid' => $this->getTransactionId(),
				'amount'        => $this->getAmount()
			));
		}
		
		/**
		 * Transaction sales are submitted and immediately flagged for settlement.
		 *
		 * @param float $amount Float representing the amount to be processed.
		 *
		 * @throws Exception
		 */
		private function saleTransaction(float $amount): void {
			$this->setAmount($amount);
			$this->process(array(
				// Transaction Information
				'type'                => $this->getType(),
				'amount'              => $this->getAmount(),
				'ccnumber'            => $this->getCreditCard('account'),
				'ccexp'               => $this->getCreditCard('expiration'),
				'cvv'                 => $this->getCreditCard('cvv'),
				
				// Order Information
				'ipaddress'           => $this->getOrder('ip_address'),
				'orderid'             => $this->getOrder('id'),
				'order_description'   => $this->getOrder('description'),
				'tax'                 => $this->getOrder('tax'),
				'shipping'            => $this->getOrder('shipping'),
				'ponumber'            => $this->getOrder('po_number'),
				
				// Billing Information
				'first_name'          => $this->getBilling('first_name'),
				'last_name'           => $this->getBilling('last_name'),
				'company'             => $this->getBilling('company'),
				'address1'            => $this->getBilling('address_line_1'),
				'address2'            => $this->getBilling('address_line_2'),
				'city'                => $this->getBilling('city'),
				'state'               => $this->getBilling('state'),
				'zip'                 => $this->getBilling('zip_code'),
				'country'             => $this->getBilling('country'),
				'phone'               => $this->getBilling('phone'),
				'fax'                 => $this->getBilling('fax'),
				'email'               => $this->getBilling('email'),
				'website'             => $this->getBilling('website'),
				
				// Shipping Information
				'shipping_first_name' => $this->getShipping('first_name'),
				'shipping_last_name'  => $this->getShipping('last_name'),
				'shipping_company'    => $this->getShipping('company'),
				'shipping_address1'   => $this->getShipping('address_line_1'),
				'shipping_address2'   => $this->getShipping('address_line_2'),
				'shipping_city'       => $this->getShipping('city'),
				'shipping_state'      => $this->getShipping('state'),
				'shipping_zip'        => $this->getShipping('zip_code'),
				'shipping_country'    => $this->getShipping('country'),
				'shipping_email'      => $this->getShipping('email')
			));
		}
		
		/**
		 * Transaction updates can be used to update previous transactions with specific order information, such as a
		 * tracking number and shipping carrier.
		 *
		 * @throws Exception
		 */
		private function updateTransaction(): void {
			$this->process(array(
				// Transaction Information
				'type'              => $this->getType(),
				'transactionid'     => $this->getTransactionId(),
				
				// Order Information
				'order_description' => $this->getOrder('description'),
				'tax'               => $this->getOrder('tax'),
				'shipping'          => $this->getOrder('shipping'),
				'ponumber'          => $this->getOrder('po_number'),
				
				// Shipping Information
				'shipping_country'  => $this->getShipping('country'),
				'shipping_postal'   => $this->getShipping('zip_code')
			));
		}
		
		/**
		 * This action is used for doing an "Account Verification" on the cardholder's credit card without actually doing an
		 * authorization.
		 *
		 * @param float $amount Float representing the amount to be validated.
		 *
		 * @throws Exception
		 */
		private function validateTransaction(float $amount): void {
			$this->setAmount($amount);
			$this->process(array(
				// Transaction Information
				'type'     => $this->getType(),
				'amount'   => $this->getAmount(),
				'ccnumber' => $this->getCreditCard('account'),
				'ccexp'    => $this->getCreditCard('expiration'),
				'cvv'      => $this->getCreditCard('cvv')
			));
		}
		
		/**
		 * Transaction voids will cancel an existing sale or captured authorization. In addition, non-captured authorizations
		 * can be voided to prevent any future capture. Voids can only occur if the transaction has not been settled.
		 *
		 * @throws Exception
		 */
		private function voidTransaction(): void {
			$this->process(array(
				// Transaction Information
				'type'          => $this->getType(),
				'transactionid' => $this->getTransactionId()
			));
		}
		
		/**
		 * @return bool
		 */
		#[Pure]
		public function isSandbox(): bool {
			return $this->config->getMode() == Config::DEVELOPMENT_MODE;
		}
		
		/**
		 * String representing the transaction ID from the original transaction.
		 *
		 * @param string|null $transaction_id
		 */
		public function setTransactionId(?string $transaction_id): void {
			$this->transaction_id = $transaction_id;
		}
	}