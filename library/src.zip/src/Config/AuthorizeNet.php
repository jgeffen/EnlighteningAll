<?php
	/*
	Copyright (c) 2022 FenclWebDesign.com
	This script may not be copied, reproduced or altered in whole or in part.
	We check the Internet regularly for illegal copies of our scripts.
	Do not edit or copy this script for someone else, because you will be held responsible as well.
	This copyright shall be enforced to the full extent permitted by law.
	Licenses to use this script on a single website may be purchased from FenclWebDesign.com
	@Author: Deryk
	*/
	
	namespace Config;
	
	use Exception;
	use Helpers;
	use net\authorize\api\constants\ANetEnvironment;
	
	
	class AuthorizeNet {
		public const string DEVELOPMENT_MODE = 'development';
		public const string PRODUCTION_MODE  = 'production';
		
		protected string  $config_path;
		protected string  $mode = self::DEVELOPMENT_MODE;
		private ?string $api_login_id;
		private ?string $transaction_key;
		private ?string $client_key;
		private ?string $currency;
		
		/**
		 * @param string|null $mode "development" | "production"
		 *
		 * @throws Exception
		 */
		public function __construct(?string $mode = NULL) {
			$this->config_path = Helpers::PathAbsolute('/library/settings/authorizenet.json');
			
			if(!$config = json_decode(file_get_contents($this->config_path), TRUE)) throw new Exception(sprintf("Unable to open %s.", basename($this->config_path)));
			
			$this->mode = $mode ?? $config['mode'];
			
			if(!in_array($this->mode, array('development', 'production'))) throw new Exception(sprintf("Unknown mode \"%s\".", $this->mode));
			
			foreach($config[$this->mode] as $key => $value) {
				if(property_exists($this, $key) && !isset($this->$key)) {
					$this->$key = $value;
				}
			}
		}
		
		/**
		 * Gets the appropriate Authorize.Net environment based on mode.
		 *
		 * @return string
		 */
		public function getEnvironment(): string {
			return $this->mode === 'production'
				? 'https://api2.authorize.net/xml/v1/request.api'
				: 'https://apitest.authorize.net/xml/v1/request.api';
		}
		
		/**
		 * @return string
		 */
		public function getClientKey(): string {
			return $this->client_key;
		}
		
		/**
		 * @return string
		 */
		public function getConfigPath(): string {
			return $this->config_path;
		}
		
		/**
		 * @return string
		 */
		public function getMode(): string {
			return $this->mode;
		}
		
		/**
		 * @return null|string
		 */
		public function getApiLoginId(): ?string {
			return $this->api_login_id;
		}
		
		/**
		 * @return null|string
		 */
		public function getTransactionKey(): ?string {
			return $this->transaction_key;
		}
		
		/**
		 * @return null|string
		 */
		public function getCurrency(): ?string {
			return $this->currency;
		}
		
		/**
		 * @return bool
		 */
		public function isSandbox(): bool {
			return $this->mode == self::DEVELOPMENT_MODE;
		}
	}